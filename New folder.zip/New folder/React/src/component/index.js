// import "./index.css";
import { useState, useEffect } from "react";
import Axios from "axios";

function App() {
  const [listOfCar, setListOfCar] = useState([]);
  const [name, setName] = useState("");
  const [detail, setDetail] = useState("");
  const [price, setPrice] = useState(0);

  useEffect(() => {
    Axios.get("http://localhost:3003/getCar").then((response) => {
      setListOfCar(response.data);
    });
  }, []);

  const addCar = () => {
    Axios.post("http://localhost:3003/addCar", {
        name:name,
        detail:detail,
        price:price,
    }).then((response) => {
      setListOfCar([
        ...listOfCar,
        {
          name:name,
          detail:detail,
          price:price,
        },
      ]);
    });
  };

  return (
    <div className="contain">
      <div>
        <h2><u><center>Pak Wheels Automobile Company</center></u></h2>
        <br></br>
        <input
          type="text"
          placeholder="Name of car"
          onChange={(event) => {
            setName(event.target.value);
          }}
        />
        <br></br>
        <br></br>
        <br></br>
        <input
          type="number"
          placeholder="Price of car"
          onChange={(event) => {
            setPrice(event.target.value);
          }}
        />
        <br></br>
        <br></br>
        <br></br>
        <input
          type="text"
          placeholder="Details Of car"
          onChange={(event) => {
            setDetail(event.target.value);
          }}
        />
        <br></br>
        <br></br>
        <br></br>
        <button onClick={addCar}>Add New Car</button>
        <br></br>
        <h2><u><center>CAR DATA</center></u></h2>
        <h4>--------------------------------------------------------------</h4>
      </div>
      <div className="usersDisplay">
        {listOfCar.map((car) => {
          return (
            <div>
              <h1>Name: {car.name}</h1>
              <h1>Detail: {car.detail}</h1>
              <h1>Price: {car.price}</h1>
              <h4>--------------------------------------------------------------</h4>
            </div>
          );
        })}
         <br></br>
         <h3><center>@CopyRight All Rights Reserved: Syed Muhammad Shoaib</center></h3>
      </div>
    </div>

  );
}

export default App;