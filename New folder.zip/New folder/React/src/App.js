// import logo from '.logo.svg';
import './App.css';
import Component from './component/index';

function App(){
  return (
    <div className='App'>
<Component />
    </div>
  )
}
export default App;