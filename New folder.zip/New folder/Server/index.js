const express = require('express');
const app = express();
const mongoose =require('mongoose');
const cors = require("cors")

const CarsModel = require("./car")
var router = express.Router();



app.use(express.json());
app.use(cors())
app.use(router)
mongoose.connect("mongodb://localhost:27017",{
    useNewUrlParser: true
})

const conSuccess = mongoose.connection
conSuccess.once('open',_ =>{
    console.log("Database connected");
})

router.route('/addCar').post(async(req,res)=>{
    const name = req.body.name;
      const detail = req.body.detail;
      const price = req.body.price;
    const newCar = new CarsModel({name: name, detail: detail, price:price});
      await newCar.save();
    
      res.json({msg:'success'});
    })
    

    router.route('/.getCar').get(async(req,res)=>{
        CarsModel.find({}, (err, result) => {
            if (err) {
              res.json(err);
            } else {
              res.json(result);
            }
    });
    });

    app.get('/',(req,res)=>{
        console.log('Found');
    })

app.listen('3003',()=>{
    console.log('server started');
})




